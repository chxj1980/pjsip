
General Configuration Optimization
**********************************

PJSUA2 Settings
===============

CPU Optimization
================
A general guide on how to reduce CPU utilization can be found here: `FAQ-CPU utilization`_.

.. _`FAQ-CPU utilization`: http://trac.pjsip.org/repos/wiki/FAQ#cpu

